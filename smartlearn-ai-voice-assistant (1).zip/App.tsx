import React, { useState } from 'react';
import { Section } from './types';
import { useVoiceAssistant } from './hooks/useVoiceAssistant';
import { students, studentProgress, marathiStudents, reminders, studyContent, recommendations } from './data/mockData';
import { UserGroupIcon, ChartBarIcon, BookOpenIcon, BellAlertIcon, TranslateIcon, LightBulbIcon, HomeIcon } from './components/icons';
import { FaceActivation } from './components/FaceActivation';

// Define components inside their own const to avoid re-declaration on re-render.
const StudentRecords: React.FC = () => (
    <div>
        <h2 className="text-3xl font-bold text-orange-400 mb-6">Student Records</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {students.map(student => (
                <div key={student.id} className="bg-gray-800 p-6 rounded-lg border border-orange-500/30 shadow-lg hover:shadow-orange-500/20 transition-shadow duration-300">
                    <h3 className="text-xl font-semibold text-orange-400">{student.name}</h3>
                    <p className="text-gray-400">Class: {student.class}</p>
                    <p className="text-gray-400">Roll No: {student.rollNo}</p>
                    <p className="text-gray-400">Address: {student.address}</p>
                    <p className="text-gray-400">Mobile: {student.mobile}</p>
                </div>
            ))}
        </div>
    </div>
);

const StudentProgress: React.FC = () => (
    <div>
        <h2 className="text-3xl font-bold text-orange-400 mb-6">Student Progress</h2>
        <div className="space-y-6">
            {studentProgress.map(progress => (
                <div key={progress.studentId} className="bg-gray-800 p-6 rounded-lg border border-orange-500/30 shadow-lg">
                    <h3 className="text-xl font-semibold text-orange-400">{progress.studentName}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                        <div><p className="font-bold text-gray-300">CGPA:</p><p className="text-orange-400 text-lg">{progress.cgpa}</p></div>
                        <div><p className="font-bold text-gray-300">Attendance:</p><p className="text-orange-400 text-lg">{progress.attendance}%</p></div>
                        {Object.entries(progress.subjects).map(([subject, marks]) => (
                            <div key={subject}><p className="font-bold text-gray-300">{subject}:</p><p className="text-orange-400 text-lg">{marks}</p></div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    </div>
);

const StudyContent: React.FC = () => (
    <div>
        <h2 className="text-3xl font-bold text-orange-400 mb-6">Study Content</h2>
        {studyContent.map(content => (
            <div key={content.id} className="bg-gray-800 p-6 rounded-lg border border-orange-500/30 shadow-lg">
                <h3 className="text-xl font-semibold text-orange-400">{content.title}</h3>
                <p className="text-gray-400 mb-4">{content.type}</p>
                <div className="whitespace-pre-line text-gray-300 leading-relaxed">{content.transcript}</div>
            </div>
        ))}
    </div>
);

const Reminders: React.FC = () => (
    <div>
        <h2 className="text-3xl font-bold text-orange-400 mb-6">Reminders</h2>
        <div className="space-y-4">
            {reminders.map(reminder => (
                <div key={reminder.id} className="bg-gray-800 p-6 rounded-lg border border-orange-500/30 shadow-lg flex justify-between items-center">
                    <div>
                        <h3 className="text-xl font-semibold text-orange-400">{reminder.task}</h3>
                        <p className="text-gray-400">Subject: {reminder.subject}</p>
                    </div>
                    <p className="text-lg font-bold text-orange-500">{reminder.dueDate}</p>
                </div>
            ))}
        </div>
    </div>
);

const MarathiRecords: React.FC = () => (
    <div>
        <h2 className="text-3xl font-bold text-orange-400 mb-6">Marathi Student Records</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {marathiStudents.map(student => (
                <div key={student.id} className="bg-gray-800 p-6 rounded-lg border border-orange-500/30 shadow-lg">
                    <h3 className="text-xl font-semibold text-orange-400">{student.name}</h3>
                    <p className="text-gray-400">Marks: {student.marks}</p>
                    <p className="text-gray-400">Attendance: {student.attendance}%</p>
                </div>
            ))}
        </div>
    </div>
);

const Recommendations: React.FC = () => (
    <div>
        <h2 className="text-3xl font-bold text-orange-400 mb-6">Study Recommendations (AIML)</h2>
        <div className="space-y-4">
            {recommendations.map(rec => (
                <div key={rec.id} className="bg-gray-800 p-6 rounded-lg border border-orange-500/30 shadow-lg">
                    <h3 className="text-xl font-semibold text-orange-400">{rec.title}</h3>
                    <p className="text-gray-400">by {rec.author}</p>
                </div>
            ))}
        </div>
    </div>
);

const Dashboard: React.FC = () => (
  <div className="text-center">
    <h2 className="text-4xl font-bold text-orange-400 mb-4 font-orbitron">Welcome to SmartLearn AI</h2>
    <p className="text-xl text-gray-300 max-w-2xl mx-auto">
      Your voice-powered student management dashboard. Click the microphone icon and issue a command like "Open student records" to get started.
    </p>
  </div>
);


const App: React.FC = () => {
    const [activeSection, setActiveSection] = useState<Section>('dashboard');
    const [isFaceActivationEnabled, setIsFaceActivationEnabled] = useState(false);
    const { isListening, isSpeaking, isSupported, startListening } = useVoiceAssistant({
        onSectionChange: setActiveSection,
    });

    const renderContent = () => {
        switch (activeSection) {
            case 'students': return <StudentRecords />;
            case 'progress': return <StudentProgress />;
            case 'content': return <StudyContent />;
            case 'reminders': return <Reminders />;
            case 'marathi': return <MarathiRecords />;
            case 'recommendations': return <Recommendations />;
            case 'dashboard':
            default:
              return <Dashboard/>;
        }
    };
    
    const menuItems = [
        { id: 'dashboard', label: 'Dashboard', icon: HomeIcon },
        { id: 'students', label: 'Student Records', icon: UserGroupIcon },
        { id: 'progress', label: 'Student Progress', icon: ChartBarIcon },
        { id: 'content', label: 'Study Content', icon: BookOpenIcon },
        { id: 'reminders', label: 'Reminders', icon: BellAlertIcon },
        { id: 'marathi', label: 'Marathi Records', icon: TranslateIcon },
        { id: 'recommendations', label: 'Recommendations', icon: LightBulbIcon },
    ];

    return (
        <div className="min-h-screen flex flex-col md:flex-row bg-gray-900 text-gray-200">
            <aside className="w-full md:w-64 bg-black/50 p-4 md:p-6 flex-shrink-0">
                <h1 className="text-3xl font-bold text-orange-500 mb-8 text-center font-orbitron">SmartLearn AI</h1>
                <nav className="flex md:flex-col justify-around md:justify-start md:space-y-2">
                    {menuItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => setActiveSection(item.id as Section)}
                            className={`flex items-center p-3 rounded-lg w-full text-left transition-all duration-300 text-sm md:text-base ${activeSection === item.id ? 'bg-orange-600 text-white shadow-lg' : 'hover:bg-gray-700/50'}`}
                        >
                            <item.icon className="w-5 h-5 mr-0 md:mr-3" />
                            <span className="hidden md:inline">{item.label}</span>
                        </button>
                    ))}
                </nav>
                 <div className="border-t border-gray-700 mt-auto pt-4 hidden md:block">
                    <label htmlFor="face-toggle" className="flex items-center cursor-pointer">
                        <div className="relative">
                            <input type="checkbox" id="face-toggle" className="sr-only" checked={isFaceActivationEnabled} onChange={() => setIsFaceActivationEnabled(!isFaceActivationEnabled)} />
                            <div className="block bg-gray-600 w-10 h-6 rounded-full"></div>
                            <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition ${isFaceActivationEnabled ? 'transform translate-x-full bg-orange-500' : ''}`}></div>
                        </div>
                        <div className="ml-3 text-gray-200 text-sm">Activate on Face</div>
                    </label>
                </div>
            </aside>

            <main className="flex-1 p-6 md:p-10 overflow-auto">
                {renderContent()}
            </main>
            
            <FaceActivation 
                isEnabled={isFaceActivationEnabled}
                onActivate={startListening}
                isListening={isListening}
                isSpeaking={isSpeaking}
            />

            <div className="fixed bottom-6 right-6 z-10">
                <button
                    onClick={startListening}
                    disabled={!isSupported || isListening}
                    className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 transform
                        ${isListening ? 'bg-red-500 animate-pulse' : 'bg-orange-500 hover:bg-orange-600'} 
                        ${isSpeaking ? 'shadow-2xl shadow-cyan-400/50' : 'shadow-2xl shadow-orange-500/50'}
                        disabled:bg-gray-600 disabled:cursor-not-allowed`}
                    aria-label="Activate Voice Assistant"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                    {isSpeaking && (
                         <span className="absolute h-full w-full rounded-full bg-cyan-400/75 animate-ping opacity-75"></span>
                    )}
                </button>
            </div>
        </div>
    );
};

export default App;
