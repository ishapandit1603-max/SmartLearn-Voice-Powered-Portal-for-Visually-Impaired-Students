import { Student, StudentProgress, MarathiStudent, Reminder, StudyContent, Recommendation } from '../types';

export const students: Student[] = [
  { id: '1', name: 'Aarav Sharma', address: '123 Film City Road, Mumbai', mobile: '9876543210', class: '10th', rollNo: '101' },
  { id: '2', name: 'Diya Patel', address: '456 MG Road, Bangalore', mobile: '9876543211', class: '9th', rollNo: '203' },
  { id: '3', name: 'Rohan Gupta', address: '789 Connaught Place, Delhi', mobile: '9876543212', class: '8th', rollNo: '305' },
  { id: '4', name: 'Priya Singh', address: '101 Park Street, Kolkata', mobile: '9876543213', class: '10th', rollNo: '102' },
  { id: '5', name: 'Arjun Verma', address: '212 Marina Beach Road, Chennai', mobile: '9876543214', class: '9th', rollNo: '204' },
];

export const studentProgress: StudentProgress[] = [
  { studentId: '1', studentName: 'Aarav Sharma', cgpa: 9.2, attendance: 95, subjects: { 'Physics': 94, 'Mathematics': 98 } },
  { studentId: '2', studentName: 'Diya Patel', cgpa: 8.8, attendance: 91, subjects: { 'Biology': 89, 'Chemistry': 92 } },
  { studentId: '3', studentName: 'Rohan Gupta', cgpa: 8.5, attendance: 88, subjects: { 'History': 85, 'Geography': 90 } },
  { studentId: '4', studentName: 'Priya Singh', cgpa: 9.5, attendance: 98, subjects: { 'Physics': 97, 'Mathematics': 99 } },
  { studentId: '5', studentName: 'Arjun Verma', cgpa: 8.9, attendance: 93, subjects: { 'Biology': 91, 'Chemistry': 94 } },
];

export const marathiStudents: MarathiStudent[] = [
    { id: '1', name: 'ऐश्वर्या जोशी', nameEn: 'Aishwarya Joshi', marks: 88, attendance: 92 },
    { id: '2', name: 'पूजा देशमुख', nameEn: 'Pooja Deshmukh', marks: 92, attendance: 95 },
    { id: '3', name: 'स्नेहा पाटील', nameEn: 'Sneha Patil', marks: 85, attendance: 90 },
    { id: '4', name: 'राधिका कुलकर्णी', nameEn: 'Radhika Kulkarni', marks: 95, attendance: 98 },
    { id: '5', name: 'गौरी शिंदे', nameEn: 'Gauri Shinde', marks: 89, attendance: 91 },
];

export const reminders: Reminder[] = [
  { id: '1', subject: 'Physics', task: 'Chapter 5 Quiz', dueDate: '2023-10-28' },
  { id: '2', subject: 'Mathematics', task: 'Algebra Assignment Submission', dueDate: '2023-10-30' },
  { id: '3', subject: 'Chemistry', task: 'Lab Report Due', dueDate: '2023-11-02' },
];

export const studyContent: StudyContent[] = [
    {
        id: '1',
        title: 'ML Terminologies',
        type: 'Document',
        transcript: `
        Here are the Machine Learning Terminologies.
        Overfitting: Model learns noise, performs badly on new data.
        Underfitting: Model too simple, fails to learn patterns.
        Supervised Learning: Learns from labeled data, for example, Logistic Regression, Linear Regression.
        Unsupervised Learning: Finds hidden patterns, for example, PCA, K-Means, DBSCAN.
        Reinforcement Learning: Agent learns via rewards, for example, Game AI, Robotics.
        PCA, or Principal Component Analysis: Dimensionality reduction (Unsupervised).
        K-Means Clustering: Groups similar data points (Unsupervised).
        DBSCAN: Density-based clustering (Unsupervised).
        Logistic Regression: Predicts classes (Supervised, classification).
        Linear Regression: Predicts continuous values (Supervised, regression).
        Bias: Error from wrong assumptions; too simple.
        Variance: Error from model sensitivity to data.
        `,
    },
];

export const recommendations: Recommendation[] = [
  { id: '1', title: 'Pattern Recognition and Machine Learning', author: 'Christopher M. Bishop' },
  { id: '2', title: 'Deep Learning with Python', author: 'François Chollet' },
  { id: '3', title: 'The Hundred-Page Machine Learning Book', author: 'Andriy Burkov' },
  { id: '4', title: 'Artificial Intelligence: A Modern Approach', author: 'Stuart Russell and Peter Norvig' },
  { id: '5', title: 'Hands-On Machine Learning with Scikit-Learn, Keras & TensorFlow', author: 'Aurélien Géron' },
];