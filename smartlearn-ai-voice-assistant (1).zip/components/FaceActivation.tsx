import React, { useEffect, useRef, useState } from 'react';

// Make faceapi available in the window scope
declare const faceapi: any;

interface FaceActivationProps {
  onActivate: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  isEnabled: boolean;
}

export const FaceActivation: React.FC<FaceActivationProps> = ({ onActivate, isListening, isSpeaking, isEnabled }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [camError, setCamError] = useState<string | null>(null);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    const loadModels = async () => {
      // Path to models should be relative to where the library is loaded from
      const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/';
      try {
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        ]);
        setModelsLoaded(true);
        console.log("Face detection models loaded.");
      } catch (error) {
        console.error("Error loading face detection models:", error);
      }
    };
    if (typeof faceapi !== 'undefined') {
        loadModels();
    } else {
        console.error("face-api.js not loaded");
    }
  }, []);

  const startVideo = () => {
    navigator.mediaDevices.getUserMedia({ video: {} })
      .then(stream => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCamError(null);
      })
      .catch(err => {
        console.error("Error accessing camera:", err);
        setCamError("Camera access denied. Please enable permissions.");
      });
  };

  const stopVideo = () => {
      if (videoRef.current && videoRef.current.srcObject) {
          const stream = videoRef.current.srcObject as MediaStream;
          stream.getTracks().forEach(track => track.stop());
          videoRef.current.srcObject = null;
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
  };

  useEffect(() => {
    if (isEnabled && modelsLoaded) {
      startVideo();
    } else {
      stopVideo();
    }

    return () => {
        stopVideo();
    };
  }, [isEnabled, modelsLoaded]);


  useEffect(() => {
    if (isEnabled && modelsLoaded && !intervalRef.current && videoRef.current) {
      intervalRef.current = window.setInterval(async () => {
        if (videoRef.current && !isListening && !isSpeaking) {
          const detections = await faceapi.detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions());
          if (detections.length > 0) {
            console.log('Face detected, activating assistant.');
            onActivate();
          }
        }
      }, 1000); // Check every second
    } else if ((!isEnabled || isListening || isSpeaking) && intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    
    return () => {
      if(intervalRef.current) clearInterval(intervalRef.current);
    }

  }, [isEnabled, modelsLoaded, onActivate, isListening, isSpeaking]);


  if (!isEnabled) return null;

  return (
    <div className="fixed bottom-6 left-6 w-40 h-30 bg-black border-2 border-orange-500/50 rounded-lg shadow-2xl p-2 z-50">
      <video ref={videoRef} autoPlay muted className="w-full h-full object-cover rounded-md" />
      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white text-xs text-center p-1 pointer-events-none">
        {!modelsLoaded && <p>Loading model...</p>}
        {modelsLoaded && camError && <p className="text-red-400">{camError}</p>}
        {modelsLoaded && !camError && <p>Scanning for face...</p>}
      </div>
    </div>
  );
};
