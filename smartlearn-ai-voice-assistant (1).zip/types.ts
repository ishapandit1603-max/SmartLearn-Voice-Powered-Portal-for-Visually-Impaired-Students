export type Section = 'students' | 'progress' | 'content' | 'reminders' | 'marathi' | 'recommendations' | 'dashboard';

export interface Student {
  id: string;
  name: string;
  address: string;
  mobile: string;
  class: string;
  rollNo: string;
}

export interface StudentProgress {
  studentId: string;
  studentName: string;
  cgpa: number;
  attendance: number;
  subjects: {
    [subjectName: string]: number;
  };
}

export interface MarathiStudent {
  id: string;
  name: string;
  nameEn: string;
  marks: number;
  attendance: number;
}

export interface Reminder {
  id: string;
  subject: string;
  task: string;
  dueDate: string;
}

export interface StudyContent {
  id: string;
  title: string;
  type: string;
  transcript: string;
}

export interface Recommendation {
  id: string;
  title: string;
  author: string;
}