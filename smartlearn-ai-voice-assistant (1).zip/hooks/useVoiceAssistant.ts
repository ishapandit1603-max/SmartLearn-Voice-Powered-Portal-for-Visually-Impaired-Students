
import { useState, useEffect, useCallback } from 'react';
// FIX: Removed data variables from type import. Data is imported from mockData.
import { Section } from '../types';
import { students as studentsData, studyContent as studyContentData, studentProgress as studentProgressData, reminders as remindersData, marathiStudents as marathiStudentsData, recommendations as recommendationsData } from '../data/mockData';

// Type declarations for Speech Recognition API
interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  onend: () => void;
}
interface SpeechRecognitionEvent {
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionResultList {
  length: number;
  [index: number]: SpeechRecognitionResult;
}
interface SpeechRecognitionResult {
  [index: number]: SpeechRecognitionAlternative;
}
interface SpeechRecognitionAlternative {
  transcript: string;
}
interface SpeechRecognitionErrorEvent {
  error: string;
}
declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

interface VoiceAssistantOptions {
  onSectionChange: (section: Section) => void;
}

const toMarathiNumberWord = (num: number): string => {
    const words: { [key: number]: string } = {
        85: 'पंच्याऐंशी',
        88: 'अठ्ठ्याऐंशी',
        89: 'एकोणनव्वद',
        90: 'नव्वद',
        91: 'एक्क्याण्णव',
        92: 'ब्याण्णव',
        95: 'पंच्याण्णव',
        98: 'अठ्ठ्याण्णव',
    };
    return words[num] || num.toString();
};

export const useVoiceAssistant = ({ onSectionChange }: VoiceAssistantOptions) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  const startListening = useCallback(() => {
    if (recognition && !isListening) {
      setIsListening(true);
      recognition.start();
    }
  }, [recognition, isListening]);

  const speak = useCallback((text: string, lang = 'en-US', onEnd?: () => void) => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = lang;
        utterance.rate = 0.9;
        utterance.pitch = 1.1;
        utterance.volume = 0.9;
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => {
            setIsSpeaking(false);
            if (onEnd) {
                onEnd();
            }
        };
        utterance.onerror = () => {
            setIsSpeaking(false);
        };
        window.speechSynthesis.speak(utterance);
    }
  }, []);

  const processVoiceCommand = useCallback((command: string) => {
    console.log('Voice command received:', command);

    if (command.includes('marathi record')) {
        onSectionChange('marathi');
        const marathiDetails = marathiStudentsData.map(student => {
            const marks = toMarathiNumberWord(student.marks);
            const attendance = toMarathiNumberWord(student.attendance);
            return `${student.name}, गुण ${marks}, उपस्थिती ${attendance} टक्के`;
        }).join('. ');
        speak(`सादर करत आहोत मराठी विद्यार्थ्यांचे रेकॉर्ड. ${marathiDetails}`, 'mr-IN');
    } else if (command.includes('student record')) {
      onSectionChange('students');
      const studentDetails = studentsData.map(s => `${s.name}, from ${s.address}, class ${s.class}, mobile number ${s.mobile}`).join('. ');
      speak(`Opening student records. Here are the students: ${studentDetails}`);
    } else if (command.includes('study content')) {
      onSectionChange('content');
      const content = studyContentData.find(c => c.title.toLowerCase().includes('ml terminologies'));
      if (content) {
        speak(`Reading study content: ${content.title}. ${content.transcript}`);
      } else {
        speak('I could not find the specified study content.');
      }
    } else if (command.includes('student progress')) {
      onSectionChange('progress');
      const progressDetails = studentProgressData.map(p => `${p.studentName} has a C G P A of ${p.cgpa}, and an attendance of ${p.attendance} percent. Marks in subjects are: ${Object.entries(p.subjects).map(([sub, mark]) => `${sub}: ${mark}`).join(', ')}`).join('. ');
      speak(`Reading student progress. ${progressDetails}`);
    } else if (command.includes('reminder')) {
        onSectionChange('reminders');
        const reminderDetails = remindersData.map(r => `Reminder for ${r.subject}: ${r.task} is due on ${r.dueDate}`).join('. ');
        speak(`Here are your reminders. ${reminderDetails}`);
    } else if (command.includes('recommendation')) {
        onSectionChange('recommendations');
        const recommendationDetails = recommendationsData.map(r => `${r.title} by ${r.author}`).join('. ');
        speak(`Here are some study recommendations for A I M L. ${recommendationDetails}`);
    } else if (command.includes('stop speaking') || command.includes('stop')) {
        if (typeof window !== 'undefined' && window.speechSynthesis) {
            window.speechSynthesis.cancel();
            setIsSpeaking(false);
        }
    } else {
        speak("I did not understand that command. Please try again.");
    }

  }, [onSectionChange, speak]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognitionAPI) {
        setIsSupported(true);
        const recognitionInstance = new SpeechRecognitionAPI();
        recognitionInstance.continuous = false;
        recognitionInstance.interimResults = false;
        recognitionInstance.lang = 'en-US';

        recognitionInstance.onresult = (event) => {
          const command = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
          processVoiceCommand(command);
          setIsListening(false);
        };

        recognitionInstance.onerror = (event) => {
          console.error('Speech recognition error:', event.error);
          setIsListening(false);
        };

        recognitionInstance.onend = () => {
          setIsListening(false);
        };
        
        setRecognition(recognitionInstance);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [processVoiceCommand]);

  const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop();
      setIsListening(false);
    }
  };

  const stopSpeaking = () => {
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
      }
  };

  return {
    isListening,
    isSpeaking,
    isSupported,
    startListening,
    stopListening,
    stopSpeaking,
  };
};